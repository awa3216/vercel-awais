import { crewedYachtMetadata } from "@/lib/metadata";

export const metadata = crewedYachtMetadata;
export default function CrewedBoats() {
    return (
        <div>
        </div>
    );
}
