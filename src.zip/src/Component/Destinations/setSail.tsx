import { Fragment } from "react";
import SetSail from "@/common/yarchtcharter"
const Setsail = () => {
  return (
    <Fragment>
      <SetSail
        bgImage="/images/Banner2.png"
        bgColor="#000000"
        overlayOpacity={0.028} />
    </Fragment>
  );
};
export default Setsail;
