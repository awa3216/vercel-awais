import HeroSection2 from "@/common/hero2";
const HeroSection = () => {
    return (
<HeroSection2
  heading="Blog"
  breadcrumb="Blog"
  backgroundImage="/images/blogimg1.png"
/>  
    )
}
export default HeroSection;