import PngIcons from "@/icons/pngIcon"
import { styles, combine } from "@/styles"

const AboutSection = () => {
    return (
        <div className={combine(styles.container, "my-12 md:my-14 lg:my-16 xl:my-18")}>
            <div className={combine(styles.grid2Col, "md:gap-6 lg:gap-8 xl:gap-16")}>
                <div>
                    <div className="flex items-center">
                        <p className="w-13 md:w-15 lg:w-18 xl:w-21 border-b-3 border-mustard z-10"></p>
                        <p className={combine("text-mustard font-semibold font-inter uppercase relative z-10 ms-3", styles.p3)}>From Anchors to Adventures</p>
                    </div>
                    <p className={combine(styles.h3, "mb-3 font-semibold text-zink uppercase")}>Our Story</p>
                    <p className={combine(styles.p3, "text-zink leading-relaxed")}>Faraway Yachting began in 1996 when four passionate sailors from Austria, Norway, Australia, and the Netherlands met by chance at Kata Beach. What started as a sunset chat turned into a bold venture—offering sailing and scuba trips across Thailand, Myanmar, and even the remote Andaman Islands.<br />
                        From diving with elephants to exploring volcanic reefs, we pioneered unforgettable expeditions across Southeast Asia. Today, 25+ years later, Faraway Yachting is still owned by one of the original founders, Wolfgang from Austria.<br />
                        With five personally managed catamarans and deep local knowledge, we offer more than just a yacht—it's your gateway to adventure, backed by decades of hands-on experience and heart.</p>
                </div>
                <div className={styles.flexCenter}>
                    <img src={PngIcons.aboutimg3} alt="" />
                </div>
            </div>
            <div className={combine(styles.grid2Col, "mt-6 md:mt-8 lg:mt-11 xl:mt-14")} id="mission">
                <div className={styles.flexCenter}>
                    <img src={PngIcons.aboutimg4} alt="" />
                </div>
                <div>
                <div className="flex items-center">
                <p className="w-13 md:w-15 lg:w-18 xl:w-21 border-b-3 border-mustard z-10"></p>
                        <p className={combine("text-mustard font-semibold font-inter uppercase relative z-10 ms-3", styles.p3)}>Beyond the Horizon</p>
                    </div>
                    <p className={combine(styles.h2, "text-zink uppercase")}>Our Mission</p>
                    <p className={combine(styles.p3, "text-zink leading-relaxed")}>At Faraway Yachting, our mission is simple — create unforgettable, safe, and sustainable yacht adventures that bring joy to our guests and pride to our crew.<br />
                        We believe a happy crew means happy guests, so we invest in team spirit, personalized service, and thoughtful touches—from birthday surprises to tailor-made charters.<br />
                        Safety is our anchor. We exceed industry standards with rigorous maintenance and hands-on crew training, never compromising when it comes to protecting lives and vessels. <br />
                        As Thailand's leading sustainable yacht company, we minimize fuel use, protect marine beauty, and champion eco-conscious innovation.<br />
                        While profit keeps us afloat, people and the planet steer our course. We reinvest in our team, upgrade our yachts, and raise the bar for what a charter experience can be.
                    </p>
                </div>
            </div>
        </div>
    )
}
export default AboutSection